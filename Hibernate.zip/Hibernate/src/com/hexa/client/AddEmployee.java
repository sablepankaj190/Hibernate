package com.hexa.client;

import java.time.LocalDate;

import org.hibernate.SessionFactory;

import com.hexa.dao.EmpDaoImpl;
import com.hexa.dao.IEmpDao;
import com.hexa.entity.Emp;
import com.hexa.util.HibernateUtil;

public class AddEmployee {

	public static void main(String[] args) 
	{
	
		IEmpDao dao = new EmpDaoImpl();
		Emp emp = new Emp(1004, "Mohit", 34500, "HR", LocalDate.of(2019, 6, 17));
		String res = dao.addEmployee(emp);
		System.out.println(res);
		HibernateUtil.getSessionFactory().close();
	}	

}
